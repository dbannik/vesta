<?php
// Heading
$_['heading_title'] = 'Sales Analytics';

// Text
$_['text_order']    = 'Orders';
$_['text_customer'] = 'Customers';
$_['text_day']      = 'Today';
$_['text_week']     = 'Week';
$_['text_month']    = 'Month';
$_['text_year']     = 'Year';